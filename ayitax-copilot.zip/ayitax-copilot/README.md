# Ayitax Copilot — IA Local para VS Code

Extensión que funciona como GitHub Copilot, pero usa tus IAs locales (Ollama)
en vez de un servicio de pago. Detecta automáticamente si Ollama está
corriendo y lo usa siempre como motor.

## Qué hace

- **Autocompletado inline** (texto fantasma gris) mientras escribes, como Copilot.
- **Chat lateral** donde describes lo que necesitas.
- **Modo Agente**: analiza TODO el proyecto abierto, decide qué archivos
  crear o modificar, y aplica los cambios directamente — sin pedirte
  confirmación paso a paso.
- **Clic derecho** → "Ayitax: Arreglar este código" / "Ayitax: Explicar este código".
- Indicador en la barra de estado inferior que muestra si la IA local está conectada.

## Requisitos previos en tu Ubuntu 25.10

```bash
# 1. Instalar Ollama
curl -fsSL https://ollama.com/install.sh | sh

# 2. Arrancar el servicio (si no se inicia solo)
ollama serve &

# 3. Descargar los modelos recomendados
ollama pull codellama:13b    # para autocompletado
ollama pull mistral:7b       # para el chat / agente

# 4. Verificar que responde
curl http://localhost:11434/api/tags
```

Si tu Mini PC tiene poca RAM/VRAM, usa versiones más ligeras:
```bash
ollama pull codellama:7b
ollama pull mistral:7b-instruct-q4_0
```
Y cambia los nombres de modelo en la configuración de la extensión
(`ayitax.completionModel` / `ayitax.chatModel`).

## Instalación de la extensión

Necesitas Node.js 18+ y `vsce` (empaquetador oficial de VS Code).

```bash
# Entra en la carpeta de la extensión
cd ayitax-copilot

# Instala dependencias
npm install

# Compila
npm run compile

# Empaqueta en un .vsix instalable
npm install -g @vscode/vsce
vsce package
```

Esto genera un archivo `ayitax-copilot-1.0.0.vsix`. Instálalo con:

```bash
code --install-extension ayitax-copilot-1.0.0.vsix
```

O desde VS Code: `Ctrl+Shift+P` → "Extensions: Install from VSIX..." → selecciona el archivo.

## Uso

1. Abre cualquier proyecto en VS Code.
2. Verás un icono de Ayitax en la barra lateral izquierda — ábrelo para el chat.
3. La barra de estado (abajo a la derecha) indica si Ollama está conectado.
4. Empieza a escribir código: aparecerán sugerencias en gris (Tab para aceptar).
5. En el chat, elige:
   - **💬 Chat**: solo conversación, no toca archivos.
   - **⚙️ Agente**: escribe lo que necesitas ("repara el bug de X", "crea un
     plugin que haga Y") y la IA analiza el proyecto y modifica los archivos
     necesarios directamente.

## Configuración disponible

Desde `Ctrl+,` (Preferencias) busca "Ayitax":

| Opción | Por defecto | Descripción |
|---|---|---|
| `ayitax.ollamaUrl` | `http://localhost:11434` | URL del servidor Ollama |
| `ayitax.chatModel` | `mistral:7b` | Modelo para chat/agente |
| `ayitax.completionModel` | `codellama:13b` | Modelo para autocompletado |
| `ayitax.inlineSuggestionsEnabled` | `true` | Activa/desactiva el autocompletado |
| `ayitax.completionDelay` | `400` | Milisegundos de espera antes de sugerir |

## Notas

- Todo el procesamiento ocurre en tu propia máquina vía Ollama: no se envía
  código a ningún servidor externo, y no requiere suscripción.
- Si Ollama no está corriendo, el autocompletado simplemente no sugiere nada
  (no rompe la edición) y el chat te avisa con un mensaje claro.
- El modo Agente escribe archivos reales en disco. Como tienes Git local
  configurado (Directiva 4 del manual Ayitax), siempre puedes revertir con
  `git diff` / `git checkout` si algo no te convence.
