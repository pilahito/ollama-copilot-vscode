import * as vscode from 'vscode';
import * as path from 'path';
import { OllamaClient } from './ollamaClient';

export interface FileAction {
  type: 'create' | 'modify' | 'delete';
  filePath: string;
  content?: string;
  reason: string;
}

export interface AgentResult {
  explanation: string;
  actions: FileAction[];
}

/**
 * Agente autónomo: recibe una petición en lenguaje natural ("repara el bug del
 * pool de conexiones", "crea un plugin que..."), analiza el proyecto entero
 * relevante y devuelve una lista de acciones de archivo que aplica DIRECTAMENTE,
 * sin pedir confirmación paso a paso — igual que Copilot en modo agente.
 */
export class AyitaxAgent {
  private ollama: OllamaClient;
  private outputChannel: vscode.OutputChannel;

  // Extensiones que se incluyen al escanear el proyecto para dar contexto a la IA
  private readonly RELEVANT_EXTENSIONS = [
    '.ts', '.js', '.java', '.kt', '.py', '.yml', '.yaml',
    '.json', '.md', '.sh', '.sql', '.conf', '.properties'
  ];

  private readonly IGNORE_DIRS = [
    'node_modules', '.git', 'dist', 'build', 'out', 'target', '.vscode'
  ];

  constructor(ollama: OllamaClient) {
    this.ollama = ollama;
    this.outputChannel = vscode.window.createOutputChannel('Ayitax Agente');
  }

  /**
   * Punto de entrada principal: el usuario escribe lo que necesita,
   * el agente analiza el proyecto y ejecuta los cambios.
   */
  async handleRequest(
    userPrompt: string,
    onProgress: (msg: string) => void
  ): Promise<AgentResult> {
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
      throw new Error('No hay ninguna carpeta de proyecto abierta en VS Code.');
    }

    const rootPath = workspaceFolders[0].uri.fsPath;

    onProgress('🔍 Escaneando estructura del proyecto...');
    const projectTree = await this.scanProjectStructure(rootPath);

    onProgress('🧠 Analizando qué archivos son relevantes para tu petición...');
    const relevantFiles = await this.identifyRelevantFiles(userPrompt, projectTree, rootPath);

    onProgress(`📂 Leyendo ${relevantFiles.length} archivo(s) relevante(s)...`);
    const fileContents = await this.readFiles(relevantFiles);

    onProgress('⚙️ Generando la solución (esto puede tardar un poco con IA local)...');
    const result = await this.generateSolution(userPrompt, projectTree, fileContents);

    onProgress(`✏️ Aplicando ${result.actions.length} cambio(s) en el proyecto...`);
    await this.applyActions(result.actions, rootPath);

    onProgress('✅ Listo.');
    return result;
  }

  /** Recorre el árbol del proyecto (limitado en profundidad) para dar contexto general a la IA. */
  private async scanProjectStructure(rootPath: string, depth = 0, maxDepth = 4): Promise<string[]> {
    if (depth > maxDepth) return [];
    const results: string[] = [];

    try {
      const entries = await vscode.workspace.fs.readDirectory(vscode.Uri.file(rootPath));
      for (const [name, type] of entries) {
        if (this.IGNORE_DIRS.includes(name)) continue;

        const fullPath = path.join(rootPath, name);
        if (type === vscode.FileType.Directory) {
          results.push(fullPath + '/');
          const sub = await this.scanProjectStructure(fullPath, depth + 1, maxDepth);
          results.push(...sub);
        } else {
          const ext = path.extname(name);
          if (this.RELEVANT_EXTENSIONS.includes(ext)) {
            results.push(fullPath);
          }
        }
      }
    } catch {
      // carpeta inaccesible, se ignora
    }

    return results;
  }

  /** Pide al modelo local que elija qué archivos necesita leer para resolver la petición. */
  private async identifyRelevantFiles(
    userPrompt: string,
    projectTree: string[],
    rootPath: string
  ): Promise<string[]> {
    // Recortamos el árbol si es muy grande para no saturar el contexto del modelo local
    const treeSnippet = projectTree.slice(0, 300).map(p => p.replace(rootPath, '')).join('\n');

    const prompt = `Eres Ayitax, un ingeniero de software senior. El usuario te pide lo siguiente:
"${userPrompt}"

Esta es la estructura de archivos del proyecto:
${treeSnippet}

Responde ÚNICAMENTE con una lista de las rutas de archivo (máximo 8) que necesitas leer para
resolver la petición del usuario, una por línea, sin explicaciones ni markdown. Si necesitas
crear un archivo nuevo que no existe, no lo incluyas aquí.`;

    const response = await this.ollama.generateCompletion(prompt);
    const lines = response
      .split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 0 && !l.startsWith('#'));

    // Mapeamos las rutas relativas devueltas por la IA a rutas absolutas reales del árbol
    const matched: string[] = [];
    for (const line of lines) {
      const found = projectTree.find(p => p.endsWith(line) || p.includes(line));
      if (found && !matched.includes(found)) matched.push(found);
    }

    return matched.slice(0, 8);
  }

  /** Lee el contenido de los archivos relevantes detectados. */
  private async readFiles(filePaths: string[]): Promise<Record<string, string>> {
    const contents: Record<string, string> = {};
    for (const fp of filePaths) {
      try {
        const data = await vscode.workspace.fs.readFile(vscode.Uri.file(fp));
        contents[fp] = Buffer.from(data).toString('utf-8').slice(0, 6000); // límite por archivo
      } catch {
        // archivo no legible, se omite
      }
    }
    return contents;
  }

  /**
   * Genera la solución final: explicación + lista de acciones de archivo.
   * Se le pide a la IA un formato estructurado y predecible para poder parsearlo.
   */
  private async generateSolution(
    userPrompt: string,
    projectTree: string[],
    fileContents: Record<string, string>
  ): Promise<AgentResult> {
    const contextBlock = Object.entries(fileContents)
      .map(([fp, content]) => `### Archivo: ${fp}\n\`\`\`\n${content}\n\`\`\``)
      .join('\n\n');

    const systemPrompt = `Eres Ayitax, ingeniero de software senior autónomo. Trabajas sobre un servidor
Minecraft PaperMC, MariaDB y herramientas Ubuntu/Linux, pero también ayudas con cualquier código.
Actúas de forma independiente: cuando el usuario te pide algo, decides qué archivos crear o modificar
y lo haces directamente, sin pedir confirmación intermedia. Todos los comentarios de código van en español.

Debes responder EXACTAMENTE en este formato, sin texto adicional fuera de él:

EXPLICACION:
<una explicación breve en español de lo que vas a hacer>

ACCION: CREAR | RUTA: <ruta/del/archivo.ext> | MOTIVO: <motivo breve>
<<<CONTENIDO>>>
<contenido completo del archivo nuevo>
<<<FIN>>>

ACCION: MODIFICAR | RUTA: <ruta/del/archivo.ext> | MOTIVO: <motivo breve>
<<<CONTENIDO>>>
<contenido COMPLETO del archivo ya modificado, no un diff>
<<<FIN>>>

Puedes incluir varios bloques ACCION si hace falta. Si no hace falta tocar archivos, no incluyas ningún bloque ACCION.`;

    const userMessage = `Petición del usuario: "${userPrompt}"

Archivos relevantes del proyecto:
${contextBlock || '(no se encontraron archivos existentes relevantes, puede que necesites crear uno nuevo)'}`;

    let fullResponse = '';
    await this.ollama.chatStream(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage }
      ],
      (token) => {
        fullResponse += token;
      }
    );

    return this.parseAgentResponse(fullResponse);
  }

  /** Parsea la respuesta estructurada del modelo en explicación + acciones de archivo. */
  private parseAgentResponse(raw: string): AgentResult {
    const explanationMatch = raw.match(/EXPLICACION:\s*([\s\S]*?)(?=ACCION:|$)/);
    const explanation = explanationMatch ? explanationMatch[1].trim() : raw.trim();

    const actions: FileAction[] = [];
    const actionRegex = /ACCION:\s*(CREAR|MODIFICAR|ELIMINAR)\s*\|\s*RUTA:\s*(.+?)\s*\|\s*MOTIVO:\s*(.+?)\n<<<CONTENIDO>>>([\s\S]*?)<<<FIN>>>/g;

    let match;
    while ((match = actionRegex.exec(raw)) !== null) {
      const [, tipoRaw, rutaRaw, motivo, contenido] = match;
      const typeMap: Record<string, FileAction['type']> = {
        CREAR: 'create',
        MODIFICAR: 'modify',
        ELIMINAR: 'delete'
      };
      actions.push({
        type: typeMap[tipoRaw] || 'modify',
        filePath: rutaRaw.trim(),
        content: contenido.replace(/^\n/, '').replace(/\n$/, ''),
        reason: motivo.trim()
      });
    }

    return { explanation, actions };
  }

  /** Aplica las acciones de archivo directamente sobre el disco, sin diálogos de confirmación. */
  private async applyActions(actions: FileAction[], rootPath: string) {
    for (const action of actions) {
      const fullPath = path.isAbsolute(action.filePath)
        ? action.filePath
        : path.join(rootPath, action.filePath);
      const uri = vscode.Uri.file(fullPath);

      this.outputChannel.appendLine(`[${action.type.toUpperCase()}] ${fullPath} — ${action.reason}`);

      try {
        if (action.type === 'delete') {
          await vscode.workspace.fs.delete(uri);
        } else {
          // Asegura que el directorio padre existe antes de escribir
          const dir = path.dirname(fullPath);
          await vscode.workspace.fs.createDirectory(vscode.Uri.file(dir));
          const bytes = Buffer.from(action.content || '', 'utf-8');
          await vscode.workspace.fs.writeFile(uri, bytes);
        }
      } catch (err: any) {
        this.outputChannel.appendLine(`  ⚠ Error aplicando acción: ${err.message}`);
      }
    }
    if (actions.length > 0) {
      this.outputChannel.show(true);
    }
  }
}
