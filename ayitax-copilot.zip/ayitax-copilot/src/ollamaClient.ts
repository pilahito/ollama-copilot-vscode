import * as http from 'http';
import * as vscode from 'vscode';

/**
 * Cliente para comunicarse con el servidor Ollama local.
 * Detecta automáticamente si Ollama está corriendo y gestiona
 * las peticiones de autocompletado y chat.
 */
export class OllamaClient {
  private baseUrl: string;
  private connected: boolean = false;

  constructor() {
    this.baseUrl = this.getConfig('ollamaUrl', 'http://localhost:11434');
  }

  private getConfig<T>(key: string, fallback: T): T {
    return vscode.workspace.getConfiguration('ayitax').get(key, fallback);
  }

  /** Refresca la URL desde la configuración (por si el usuario la cambió). */
  refreshConfig() {
    this.baseUrl = this.getConfig('ollamaUrl', 'http://localhost:11434');
  }

  /**
   * Comprueba si Ollama está corriendo en local.
   * Esto es lo que permite que la extensión "detecte" la IA local
   * automáticamente, sin que el usuario tenga que configurar nada más.
   */
  async checkConnection(): Promise<{ ok: boolean; models: string[] }> {
    try {
      const data = await this.httpGet('/api/tags');
      const parsed = JSON.parse(data);
      const models = (parsed.models || []).map((m: any) => m.name);
      this.connected = true;
      return { ok: true, models };
    } catch (err) {
      this.connected = false;
      return { ok: false, models: [] };
    }
  }

  isConnected(): boolean {
    return this.connected;
  }

  /** Petición GET simple sobre el API de Ollama. */
  private httpGet(path: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const url = new URL(this.baseUrl + path);
      const req = http.get(
        { hostname: url.hostname, port: url.port, path: url.pathname, timeout: 2000 },
        (res) => {
          let body = '';
          res.on('data', (chunk) => (body += chunk));
          res.on('end', () => resolve(body));
        }
      );
      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error('timeout'));
      });
    });
  }

  /**
   * Genera una sugerencia de autocompletado (no-stream, rápida).
   * Usada por el proveedor de autocompletado inline.
   */
  async generateCompletion(prompt: string, model?: string): Promise<string> {
    const useModel = model || this.getConfig('completionModel', 'codellama:13b');
    const body = JSON.stringify({
      model: useModel,
      prompt: prompt,
      stream: false,
      options: {
        temperature: 0.2,
        num_predict: 128,
        stop: ['\n\n\n']
      }
    });

    const result = await this.httpPost('/api/generate', body);
    try {
      const parsed = JSON.parse(result);
      return parsed.response || '';
    } catch {
      return '';
    }
  }

  /**
   * Chat con streaming token a token, usado por la vista de chat.
   * onToken se llama por cada fragmento recibido para actualizar la UI en vivo.
   */
  async chatStream(
    messages: { role: string; content: string }[],
    onToken: (token: string) => void,
    model?: string
  ): Promise<string> {
    const useModel = model || this.getConfig('chatModel', 'mistral:7b');
    let fullResponse = '';

    return new Promise((resolve, reject) => {
      const url = new URL(this.baseUrl + '/api/chat');
      const payload = JSON.stringify({
        model: useModel,
        messages: messages,
        stream: true
      });

      const req = http.request(
        {
          hostname: url.hostname,
          port: url.port,
          path: url.pathname,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload)
          }
        },
        (res) => {
          let buffer = '';
          res.on('data', (chunk) => {
            buffer += chunk.toString();
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';
            for (const line of lines) {
              if (!line.trim()) continue;
              try {
                const json = JSON.parse(line);
                const token = json.message?.content || '';
                if (token) {
                  fullResponse += token;
                  onToken(token);
                }
              } catch {
                // línea incompleta, se ignora
              }
            }
          });
          res.on('end', () => resolve(fullResponse));
        }
      );

      req.on('error', reject);
      req.write(payload);
      req.end();
    });
  }

  /** Petición POST simple (sin streaming) sobre el API de Ollama. */
  private httpPost(path: string, body: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const url = new URL(this.baseUrl + path);
      const req = http.request(
        {
          hostname: url.hostname,
          port: url.port,
          path: url.pathname,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body)
          },
          timeout: 8000
        },
        (res) => {
          let data = '';
          res.on('data', (chunk) => (data += chunk));
          res.on('end', () => resolve(data));
        }
      );
      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error('timeout'));
      });
      req.write(body);
      req.end();
    });
  }
}
