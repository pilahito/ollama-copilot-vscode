import * as vscode from 'vscode';
import { OllamaClient } from './ollamaClient';
import { AyitaxAgent } from './agent';

/**
 * Vista de chat en la barra lateral (como el panel de Copilot Chat).
 * Aquí el usuario escribe su petición/prompt y el agente responde,
 * analiza el proyecto y aplica los cambios él mismo.
 */
export class AyitaxChatViewProvider implements vscode.WebviewViewProvider {
  public static readonly viewType = 'ayitax.chatView';

  private view?: vscode.WebviewView;
  private ollama: OllamaClient;
  private agent: AyitaxAgent;

  constructor(private readonly extensionUri: vscode.Uri, ollama: OllamaClient) {
    this.ollama = ollama;
    this.agent = new AyitaxAgent(ollama);
  }

  resolveWebviewView(webviewView: vscode.WebviewView) {
    this.view = webviewView;
    webviewView.webview.options = { enableScripts: true };
    webviewView.webview.html = this.getHtml();

    webviewView.webview.onDidReceiveMessage(async (message) => {
      if (message.type === 'send') {
        await this.handleUserMessage(message.text, message.mode);
      } else if (message.type === 'checkConnection') {
        const status = await this.ollama.checkConnection();
        this.post({ type: 'connectionStatus', ...status });
      }
    });

    // Comprobar conexión nada más abrir la vista
    this.ollama.checkConnection().then((status) => {
      this.post({ type: 'connectionStatus', ...status });
    });
  }

  /** Permite que comandos externos (clic derecho "explicar/arreglar") empujen texto al chat. */
  public sendExternalPrompt(text: string, mode: 'chat' | 'agent' = 'chat') {
    this.view?.show?.(true);
    this.post({ type: 'prefill', text });
  }

  private post(msg: any) {
    this.view?.webview.postMessage(msg);
  }

  private async handleUserMessage(text: string, mode: 'chat' | 'agent') {
    if (mode === 'agent') {
      // MODO AGENTE: analiza el proyecto entero y aplica cambios directamente
      try {
        const result = await this.agent.handleRequest(text, (progress) => {
          this.post({ type: 'progress', text: progress });
        });

        let summary = result.explanation + '\n\n';
        if (result.actions.length > 0) {
          summary += '**Archivos modificados:**\n';
          for (const a of result.actions) {
            const icon = a.type === 'create' ? '🆕' : a.type === 'delete' ? '🗑️' : '✏️';
            summary += `${icon} \`${a.filePath}\` — ${a.reason}\n`;
          }
        } else {
          summary += '_No fue necesario modificar archivos._';
        }

        this.post({ type: 'response', text: summary, done: true });
      } catch (err: any) {
        this.post({ type: 'response', text: `⚠ Error: ${err.message}`, done: true });
      }
      return;
    }

    // MODO CHAT NORMAL: streaming directo de Ollama, sin tocar archivos
    const status = await this.ollama.checkConnection();
    if (!status.ok) {
      this.post({
        type: 'response',
        text: '⚠ No se detecta Ollama corriendo en local. Ejecuta `ollama serve` y vuelve a intentarlo.',
        done: true
      });
      return;
    }

    this.post({ type: 'responseStart' });
    try {
      await this.ollama.chatStream(
        [
          {
            role: 'system',
            content:
              'Eres Ayitax, ingeniero de software senior. Respondes siempre en español, de forma técnica y directa.'
          },
          { role: 'user', content: text }
        ],
        (token) => {
          this.post({ type: 'token', text: token });
        }
      );
      this.post({ type: 'responseEnd' });
    } catch (err: any) {
      this.post({ type: 'response', text: `⚠ Error de conexión: ${err.message}`, done: true });
    }
  }

  private getHtml(): string {
    return /* html */ `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<style>
  body {
    font-family: var(--vscode-font-family);
    background: var(--vscode-sideBar-background);
    color: var(--vscode-foreground);
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    height: 100vh;
  }
  #status-bar {
    padding: 8px 12px;
    font-size: 11px;
    border-bottom: 1px solid var(--vscode-panel-border);
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .dot { width: 7px; height: 7px; border-radius: 50%; background: #888; }
  .dot.ok { background: #3fb950; }
  .dot.fail { background: #f85149; }

  #mode-bar {
    display: flex;
    gap: 4px;
    padding: 6px 8px;
    border-bottom: 1px solid var(--vscode-panel-border);
  }
  .mode-btn {
    flex: 1;
    font-size: 11px;
    padding: 5px 8px;
    border: 1px solid var(--vscode-panel-border);
    background: var(--vscode-button-secondaryBackground);
    color: var(--vscode-foreground);
    border-radius: 4px;
    cursor: pointer;
  }
  .mode-btn.active {
    background: var(--vscode-button-background);
    color: var(--vscode-button-foreground);
    border-color: var(--vscode-focusBorder);
  }

  #messages {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .msg {
    padding: 8px 10px;
    border-radius: 6px;
    font-size: 12.5px;
    line-height: 1.5;
    white-space: pre-wrap;
  }
  .msg.user {
    background: var(--vscode-button-secondaryBackground);
    align-self: flex-end;
    max-width: 88%;
  }
  .msg.ai {
    background: var(--vscode-editor-inactiveSelectionBackground);
    align-self: flex-start;
    max-width: 92%;
  }
  .msg.progress {
    color: var(--vscode-descriptionForeground);
    font-style: italic;
    font-size: 11.5px;
  }

  #input-area {
    border-top: 1px solid var(--vscode-panel-border);
    padding: 8px;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  #prompt {
    width: 100%;
    box-sizing: border-box;
    background: var(--vscode-input-background);
    color: var(--vscode-input-foreground);
    border: 1px solid var(--vscode-input-border);
    border-radius: 4px;
    padding: 8px;
    font-family: var(--vscode-editor-font-family);
    font-size: 12.5px;
    resize: none;
    min-height: 40px;
    max-height: 120px;
  }
  #send {
    background: var(--vscode-button-background);
    color: var(--vscode-button-foreground);
    border: none;
    border-radius: 4px;
    padding: 7px;
    font-size: 12px;
    cursor: pointer;
  }
  #send:hover { background: var(--vscode-button-hoverBackground); }
  #hint { font-size: 10.5px; color: var(--vscode-descriptionForeground); }
</style>
</head>
<body>
  <div id="status-bar"><span class="dot" id="status-dot"></span><span id="status-text">Comprobando Ollama...</span></div>
  <div id="mode-bar">
    <button class="mode-btn active" id="mode-chat" onclick="setMode('chat')">💬 Chat</button>
    <button class="mode-btn" id="mode-agent" onclick="setMode('agent')">⚙️ Agente (modifica archivos)</button>
  </div>
  <div id="messages"></div>
  <div id="input-area">
    <div id="hint">Modo agente: analiza tu proyecto y crea/modifica archivos automáticamente.</div>
    <textarea id="prompt" placeholder="Describe lo que necesitas, ej: repara el bug del pool de MariaDB..."></textarea>
    <button id="send">Enviar ▶</button>
  </div>

<script>
  const vscode = acquireVsCodeApi();
  const messagesEl = document.getElementById('messages');
  const promptEl = document.getElementById('prompt');
  let mode = 'chat';
  let currentAiMsgEl = null;

  function setMode(m) {
    mode = m;
    document.getElementById('mode-chat').classList.toggle('active', m === 'chat');
    document.getElementById('mode-agent').classList.toggle('active', m === 'agent');
    document.getElementById('hint').textContent = m === 'agent'
      ? 'Modo agente: analiza tu proyecto y crea/modifica archivos automáticamente, sin pedir confirmación.'
      : 'Modo chat: solo conversación, no toca archivos del proyecto.';
  }

  function addMessage(role, text) {
    const div = document.createElement('div');
    div.className = 'msg ' + role;
    div.textContent = text;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return div;
  }

  document.getElementById('send').addEventListener('click', send);
  promptEl.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'Enter') { e.preventDefault(); send(); }
  });

  function send() {
    const text = promptEl.value.trim();
    if (!text) return;
    addMessage('user', text);
    promptEl.value = '';
    vscode.postMessage({ type: 'send', text, mode });
  }

  window.addEventListener('message', (event) => {
    const msg = event.data;
    if (msg.type === 'connectionStatus') {
      const dot = document.getElementById('status-dot');
      const txt = document.getElementById('status-text');
      if (msg.ok) {
        dot.className = 'dot ok';
        txt.textContent = 'Ollama conectado — ' + msg.models.join(', ');
      } else {
        dot.className = 'dot fail';
        txt.textContent = 'Ollama no detectado — ejecuta "ollama serve"';
      }
    } else if (msg.type === 'progress') {
      addMessage('progress', msg.text);
    } else if (msg.type === 'responseStart') {
      currentAiMsgEl = addMessage('ai', '');
    } else if (msg.type === 'token') {
      if (currentAiMsgEl) {
        currentAiMsgEl.textContent += msg.text;
        messagesEl.scrollTop = messagesEl.scrollHeight;
      }
    } else if (msg.type === 'responseEnd') {
      currentAiMsgEl = null;
    } else if (msg.type === 'response') {
      addMessage('ai', msg.text);
    } else if (msg.type === 'prefill') {
      promptEl.value = msg.text;
      promptEl.focus();
    }
  });

  vscode.postMessage({ type: 'checkConnection' });
</script>
</body>
</html>`;
  }
}
