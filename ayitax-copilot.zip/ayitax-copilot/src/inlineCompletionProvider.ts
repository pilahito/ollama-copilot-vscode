import * as vscode from 'vscode';
import { OllamaClient } from './ollamaClient';

/**
 * Proveedor de "inline completions": el texto gris fantasma que aparece
 * mientras escribes, igual que GitHub Copilot, pero generado por el
 * modelo local de Ollama (codellama por defecto).
 */
export class AyitaxInlineCompletionProvider implements vscode.InlineCompletionItemProvider {
  private ollama: OllamaClient;
  private debounceTimer: NodeJS.Timeout | undefined;
  private lastRequestId = 0;

  constructor(ollama: OllamaClient) {
    this.ollama = ollama;
  }

  async provideInlineCompletionItems(
    document: vscode.TextDocument,
    position: vscode.Position,
    context: vscode.InlineCompletionContext,
    token: vscode.CancellationToken
  ): Promise<vscode.InlineCompletionItem[] | undefined> {
    const enabled = vscode.workspace.getConfiguration('ayitax').get('inlineSuggestionsEnabled', true);
    if (!enabled) return undefined;

    // Debounce: esperamos a que el usuario deje de escribir para no saturar Ollama
    const delay = vscode.workspace.getConfiguration('ayitax').get('completionDelay', 400);
    const requestId = ++this.lastRequestId;

    await new Promise((resolve) => setTimeout(resolve, delay));
    if (token.isCancellationRequested || requestId !== this.lastRequestId) {
      return undefined;
    }

    // Construir el contexto: código antes y después del cursor
    const textBefore = document.getText(
      new vscode.Range(new vscode.Position(Math.max(0, position.line - 60), 0), position)
    );
    const textAfter = document.getText(
      new vscode.Range(position, new vscode.Position(Math.min(document.lineCount, position.line + 20), 0))
    );

    const languageId = document.languageId;
    const prompt = this.buildFimPrompt(languageId, textBefore, textAfter);

    try {
      const completion = await this.ollama.generateCompletion(prompt);
      if (token.isCancellationRequested || requestId !== this.lastRequestId) {
        return undefined;
      }

      const cleaned = this.cleanCompletion(completion, textAfter);
      if (!cleaned) return undefined;

      return [
        new vscode.InlineCompletionItem(
          cleaned,
          new vscode.Range(position, position)
        )
      ];
    } catch (err) {
      // Si Ollama no responde, simplemente no se muestra sugerencia (sin romper la edición)
      return undefined;
    }
  }

  /**
   * Construye un prompt estilo "fill-in-the-middle" para que codellama
   * entienda que debe completar el código, no explicarlo.
   */
  private buildFimPrompt(languageId: string, before: string, after: string): string {
    return `Eres un motor de autocompletado de código tipo GitHub Copilot para ${languageId}.
Completa SOLO el código que continúa de forma natural en el cursor marcado con <CURSOR>.
No repitas el código anterior. No expliques nada. No uses markdown. Responde solo con el código a insertar.

Código antes del cursor:
${before}<CURSOR>${after}

Completar desde <CURSOR>:`;
  }

  /** Limpia la respuesta del modelo: quita markdown, evita duplicar lo que ya sigue después del cursor. */
  private cleanCompletion(raw: string, textAfter: string): string {
    let text = raw;

    // Quitar bloques de markdown si el modelo los añade por costumbre
    text = text.replace(/```[\w]*\n?/g, '').replace(/```$/g, '');

    // Cortar si el modelo empieza a repetir el texto que ya viene después del cursor
    const afterStart = textAfter.slice(0, 40).trim();
    if (afterStart.length > 5) {
      const idx = text.indexOf(afterStart);
      if (idx > -1) text = text.slice(0, idx);
    }

    // Limitar a un tamaño razonable para no inundar el editor
    const lines = text.split('\n');
    if (lines.length > 25) text = lines.slice(0, 25).join('\n');

    return text.trimEnd();
  }
}
