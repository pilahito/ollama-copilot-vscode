import * as vscode from 'vscode';
import { OllamaClient } from './ollamaClient';
import { AyitaxInlineCompletionProvider } from './inlineCompletionProvider';
import { AyitaxChatViewProvider } from './chatViewProvider';
import { AyitaxAgent } from './agent';

export function activate(context: vscode.ExtensionContext) {
  const ollama = new OllamaClient();
  const statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
  statusBarItem.command = 'ayitax.checkConnection';
  context.subscriptions.push(statusBarItem);

  // ---- Detección automática de Ollama al iniciar ----
  async function refreshStatusBar() {
    const status = await ollama.checkConnection();
    if (status.ok) {
      statusBarItem.text = `$(check) Ayitax: IA local activa`;
      statusBarItem.tooltip = `Ollama conectado. Modelos: ${status.models.join(', ') || 'ninguno descargado'}`;
      statusBarItem.backgroundColor = undefined;
    } else {
      statusBarItem.text = `$(warning) Ayitax: sin IA local`;
      statusBarItem.tooltip = 'No se detecta Ollama. Ejecuta "ollama serve" en tu terminal.';
      statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
    }
    statusBarItem.show();
  }
  refreshStatusBar();
  // Reintenta la detección cada 30s, por si el usuario arranca Ollama después de abrir VS Code
  const interval = setInterval(refreshStatusBar, 30000);
  context.subscriptions.push({ dispose: () => clearInterval(interval) });

  // ---- Vista de chat lateral ----
  const chatProvider = new AyitaxChatViewProvider(context.extensionUri, ollama);
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(AyitaxChatViewProvider.viewType, chatProvider)
  );

  // ---- Autocompletado inline tipo Copilot ----
  const inlineProvider = new AyitaxInlineCompletionProvider(ollama);
  context.subscriptions.push(
    vscode.languages.registerInlineCompletionItemProvider({ pattern: '**' }, inlineProvider)
  );

  // ---- Comandos ----
  context.subscriptions.push(
    vscode.commands.registerCommand('ayitax.openChat', () => {
      vscode.commands.executeCommand('workbench.view.extension.ayitax-sidebar');
    }),

    vscode.commands.registerCommand('ayitax.checkConnection', async () => {
      await refreshStatusBar();
      const status = await ollama.checkConnection();
      if (status.ok) {
        vscode.window.showInformationMessage(
          `✓ Ayitax: Ollama conectado. Modelos disponibles: ${status.models.join(', ') || 'ninguno — descarga uno con "ollama pull codellama:13b"'}`
        );
      } else {
        vscode.window.showWarningMessage(
          '⚠ Ayitax: no se detecta Ollama en localhost:11434. Instálalo y ejecuta "ollama serve".'
        );
      }
    }),

    vscode.commands.registerCommand('ayitax.toggleInlineSuggestions', async () => {
      const config = vscode.workspace.getConfiguration('ayitax');
      const current = config.get('inlineSuggestionsEnabled', true);
      await config.update('inlineSuggestionsEnabled', !current, vscode.ConfigurationTarget.Global);
      vscode.window.showInformationMessage(
        `Ayitax: autocompletado inline ${!current ? 'activado' : 'desactivado'}.`
      );
    }),

    vscode.commands.registerCommand('ayitax.explainCode', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor || editor.selection.isEmpty) {
        vscode.window.showWarningMessage('Selecciona código primero.');
        return;
      }
      const code = editor.document.getText(editor.selection);
      vscode.commands.executeCommand('workbench.view.extension.ayitax-sidebar');
      chatProvider.sendExternalPrompt(`Explica en español qué hace este código:\n\n${code}`, 'chat');
    }),

    vscode.commands.registerCommand('ayitax.fixError', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor || editor.selection.isEmpty) {
        vscode.window.showWarningMessage('Selecciona el código con el error primero.');
        return;
      }
      const code = editor.document.getText(editor.selection);
      const filePath = editor.document.uri.fsPath;
      vscode.commands.executeCommand('workbench.view.extension.ayitax-sidebar');
      chatProvider.sendExternalPrompt(
        `Arregla el siguiente código del archivo ${filePath}. Aplica el cambio directamente:\n\n${code}`,
        'agent'
      );
    }),

    vscode.commands.registerCommand('ayitax.analyzeProject', async () => {
      vscode.commands.executeCommand('workbench.view.extension.ayitax-sidebar');
      chatProvider.sendExternalPrompt(
        'Analiza la estructura general de este proyecto y dime qué mejorarías o si detectas algún problema.',
        'agent'
      );
    })
  );

  vscode.window.setStatusBarMessage('Ayitax Copilot activado — detectando IA local...', 3000);
}

export function deactivate() {}
